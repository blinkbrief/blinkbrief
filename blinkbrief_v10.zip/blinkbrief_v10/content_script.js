// Extract main readable text from the page
function getMainContent() {
  const article = new Readability(document.cloneNode(true)).parse();
  return article ? article.textContent : document.body.innerText;
}

// Listen for popup request
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "summarise") {
    const text = getMainContent();
    const summary = text
      .split('. ')
      .slice(0, 3)
      .join('. ') + '.';
    sendResponse({ summary });
  }
});
