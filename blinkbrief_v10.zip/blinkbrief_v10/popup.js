const btn = document.getElementById('summariseBtn');
const summary = document.getElementById('summary');
const toggle = document.getElementById('toggleMode');

btn.addEventListener('click', async () => {
  summary.textContent = "Summarising...";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  chrome.tabs.sendMessage(tab.id, { action: "summarise" }, (response) => {
    if (chrome.runtime.lastError || !response) {
      summary.textContent = "Unable to summarise this page.";
    } else {
      summary.textContent = response.summary;
    }
  });
});

toggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  toggle.textContent = document.body.classList.contains('dark') ? "☀️" : "🌙";
});
