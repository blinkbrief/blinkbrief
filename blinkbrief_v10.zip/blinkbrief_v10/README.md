# Blink Brief

**Blink Brief** is a minimal Chrome Extension that summarises news articles instantly.

### ✨ Features
- One-click “Summarise This Page” button
- Smooth light/dark mode toggle
- Works on most websites (BBC, CNN, etc.)

### 📦 Installation
1. Download or clone this repo.
2. Open `chrome://extensions/` in Chrome.
3. Turn on **Developer mode**.
4. Click **Load unpacked** → select the `blinkbrief_v10` folder.
5. Done! You’ll see Blink Brief in your toolbar.

---

© 2025 Blink Brief
