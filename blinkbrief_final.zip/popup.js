document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("summariseBtn");
  const out = document.getElementById("summary");

  async function requestSummary(tabId, tryInject=false) {
    out.textContent = "Summarising…";
    chrome.tabs.sendMessage(tabId, { action: "getSummary", sentences: 3 }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        if (!tryInject) {
          chrome.scripting.executeScript(
            { target: { tabId }, files: ["content_script.js"] },
            () => { setTimeout(() => requestSummary(tabId, true), 300); }
          );
        } else {
          out.textContent = "Unable to summarise this page.";
        }
        return;
      }

      out.textContent = resp.ok ? resp.summary : "No readable article found.";
    });
  }

  btn.addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) { out.textContent = "No active tab."; return; }
    requestSummary(tab.id);
  });
});