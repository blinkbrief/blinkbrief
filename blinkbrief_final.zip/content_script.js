(() => {
  function extractReadableText() {
    const article = document.querySelector("article");
    if (article && article.innerText.trim().length > 120) return article.innerText.trim();

    const main = document.querySelector("main");
    if (main && main.innerText.trim().length > 120) return main.innerText.trim();

    const paragraphs = Array.from(document.querySelectorAll("p"))
      .filter(p => !p.closest("header, footer, nav, aside") && p.innerText.trim().length > 40);

    if (paragraphs.length) {
      let text = paragraphs.map(p => p.innerText.trim()).join("\n\n");
      if (text.length > 120) return text;
    }

    const bodyText = document.body.innerText.replace(/\s+/g, " ").trim();
    return bodyText.length > 120 ? bodyText : "";
  }

  function summarizeText(text, numSentences = 3) {
    const sentences = text.replace(/\s+/g, " ").split(/(?<=[.!?])\s+/);
    if (sentences.length <= numSentences) return sentences.join(" ");

    const words = text.toLowerCase().match(/\b[a-z]{4,}\b/g) || [];
    const freq = {};
    words.forEach(w => freq[w] = (freq[w] || 0) + 1);

    const scored = sentences.map((s, i) => {
      const sWords = s.toLowerCase().match(/\b[a-z]{4,}\b/g) || [];
      const score = sWords.reduce((a, w) => a + (freq[w] || 0), 0);
      return { index: i, sentence: s.trim(), score };
    });

    return scored
      .sort((a,b) => b.score - a.score)
      .slice(0, numSentences)
      .sort((a,b) => a.index - b.index)
      .map(s => s.sentence)
      .join(" ");
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "getSummary") {
      const text = extractReadableText();
      if (!text) return sendResponse({ ok:false });
      return sendResponse({ ok:true, summary: summarizeText(text, msg.sentences || 3) });
    }
  });
})();